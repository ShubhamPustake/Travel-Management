import java.sql.*;

class Package {
      private int id;
      private String p_name,boarding,distination,details;
      public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	private double p_rate;

      public void setId(int id) {
            this.id = id;
      }

      public String getBoarding() {
		return boarding;
	}

	public void setBoarding(String boarding) {
		this.boarding = boarding;
	}

	public String getDistination() {
		return distination;
	}

	public void setDistination(String enddate) {
		this.distination = enddate;
	}

	public int getId() {
            return id;
      }


      public void setPackage_Name(String p_name) {
            this.p_name = p_name;
      }

      public String getPackage_Name() {
            return p_name;
      }

      

      public void setProduct_Rate(double p_rate) {
            this.p_rate = p_rate;
      }

      public double getProduct_Rate() {
            return p_rate;
      }


      public void Add_package() {
            try {
                  Class.forName(DB.classname);
                  Connection conn = DriverManager.getConnection(DB.URL, DB.USERNAME, DB.PASSWORD);
                  String sql = "INSERT INTO package(ID,Package_Name,Price,Start_date,End_date)VALUES('" + getId() + "','"
                              + getPackage_Name() + "','" + getProduct_Rate() + "','" + getBoarding() + "','"
                              + getDistination() + "')";
                  PreparedStatement ps = conn.prepareStatement(sql);

                  int i = ps.executeUpdate();
                  if (i > 0) {
                        System.out.println("Product Added");
                  } else {
                        System.out.println("Failed");
                  }
                  ps.close();
                  conn.close();
            } catch (Exception e) {
                  e.printStackTrace();
            }
      }

     
      public void Update_Price() {
            try {
                  Class.forName(DB.classname);
                  Connection conn = DriverManager.getConnection(DB.URL, DB.USERNAME, DB.PASSWORD);
                  String sql = "UPDATE package SET Rate = '" + getProduct_Rate() + "' WHERE ID ='" + getId() + "'";
                  PreparedStatement ps = conn.prepareStatement(sql);
                  int i = ps.executeUpdate();
                  if (i > 0) {
                        System.out.println("Price Update");
                  } else {
                        System.out.println("Failed");
                  }
                  ps.close();
                  conn.close();
            } catch (Exception e) {
                  e.printStackTrace();
            }
      }

      public void Delete() {
            try {
                  Class.forName(DB.classname);
                  Connection conn = DriverManager.getConnection(DB.URL, DB.USERNAME, DB.PASSWORD);
                  String sql = "DELETE FROM package WHERE ID = '" + getId() + "'";
                  PreparedStatement ps = conn.prepareStatement(sql);
                  int i = ps.executeUpdate();
                  if (i > 0) {
                        System.out.println("Product Deleted");
                  } else {
                        System.out.println("Failed");
                  }
                  ps.close();
                  conn.close();
            } catch (Exception e) {
                  e.printStackTrace();
            }
      }

      public void Display() {
            try {
                  Class.forName(DB.classname);
                  Connection conn = DriverManager.getConnection(DB.URL, DB.USERNAME, DB.PASSWORD);
                  String sql = "SELECT * FROM package";
                  PreparedStatement ps = conn.prepareStatement(sql);
                  ResultSet rs = ps.executeQuery();
                  while (rs.next()) {
                        System.out.println("_________________________________________________________");
                        System.out.println("Package ID--->" + rs.getString(1));
                        System.out.println("Package Name--->" + rs.getString(2));
                        System.out.println("Price--->" + rs.getString(3));
                        System.out.println("_________________________________________________________");
                  }
                  rs.close();
                  ps.close();
                  conn.close();
            } catch (Exception e) {
                  e.printStackTrace();
            }
      }

      public void Display1() {
            try {
                  Class.forName(DB.classname);
                  Connection conn = DriverManager.getConnection(DB.URL, DB.USERNAME, DB.PASSWORD);
                  String sql = "SELECT * FROM package";
                  PreparedStatement ps = conn.prepareStatement(sql);
                  ResultSet rs = ps.executeQuery();
                  while (rs.next()) {
                        System.out.println("_________________________________________________________");
                        System.out.println("Package ID--->" + rs.getString(1));
                        System.out.println("Package Name--->" + rs.getString(2));
                        System.out.println("_________________________________________________________");
                  }
                  rs.close();
                  ps.close();
                  conn.close();
            } catch (Exception e) {
                  e.printStackTrace();
            }
      }

}