import java.sql.*;
import java.util.*;

public class User_Menu extends user_login {
    Scanner sc = new Scanner(System.in);
    Random rnd = new Random();
    user_login login = new user_login();

    String username;

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public void user_menu() {
        while (true) {
            System.out.println("1. View All Package");
            System.out.println("2. Book Package");
            System.out.println("3. Cancel Booking");
            System.out.println("0. Exit");
            System.out.print("Enter Your Choice ---> ");
            int ch1 = sc.nextInt();
            sc.nextLine();  // consume newline
            switch (ch1) {
                case 1:
                    viewAllPackages();
                    break;
                case 2:
                    booking();
                    break;
                case 3:
                	System.err.println("Enter Booking Id: ");
                	int id=sc.nextInt();
                	cancelBooking(id);
                    break;
                case 0:
                    System.out.println("Logging Out");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }

    public void booking() {
    	int val = rnd.nextInt(111111,999999);
    	System.out.println("Booking ID--->"+val);
    	viewAllPackages();
    	System.out.print("Enter package ID--->");
    	int id=sc.nextInt();
    	try {
    		Class.forName(DB.classname);
    		Connection conn=DriverManager.getConnection(DB.URL, DB.USERNAME, DB.PASSWORD);
    		String sql="SELECT * FROM package WHERE ID = '"+id+"'";
    		PreparedStatement ps=conn.prepareStatement(sql);
    		ResultSet rs=ps.executeQuery();
    		if(rs.next()) {
    			String packnm=rs.getNString(2);
    			double price=rs.getDouble(3);
    			System.out.println("package Name--->"+packnm);
    			System.out.println("package Price--->"+price);
    			System.out.print("Enter Journey Date--->");
    			sc.nextLine();
    			String date=sc.nextLine();
    			String sql1="INSERT INTO booking (ID,Package_Name,Price,Journey_Date)VALUES('"+val+"','"+packnm+"','"+price+"','"+date+"')";
    			 PreparedStatement ps1=conn.prepareStatement(sql1);
    	            int i=ps1.executeUpdate();
    	            if(i>0) {
    	            	System.out.println("Ticket is Booked");
    	            }else {
    	            	System.out.println("Failed");
    	            }
    			
    		}
    		
    	}catch(Exception e) {
    		System.out.println(e);
    	}
    }
    
    private void viewAllPackages() {
        try {
            Class.forName(DB.classname);
            Connection conn = DriverManager.getConnection(DB.URL, DB.USERNAME, DB.PASSWORD);
            String sql = "SELECT * FROM package";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                System.out.println("_________________________________________________________");
                System.out.println("Package ID ---> " + rs.getString(1));
                System.out.println("Package Name ---> " + rs.getString(2));
                System.out.println("Price ---> " + rs.getString(3));
                System.out.println("Start Date ---> " + rs.getString(4));
                System.out.println("End Date ---> " + rs.getString(5));
                System.out.println("Details ---> " + rs.getString(6));
                System.out.println("_________________________________________________________");
            }
            rs.close();
            ps.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    

    private void cancelBooking(int id) {
        // Implement cancel booking logic here
    	try {
    		Class.forName(DB.classname);
    		Connection conn=DriverManager.getConnection(DB.URL,DB.USERNAME,DB.PASSWORD);
    		String sqql="DELETE FROM package WHERE ID = '"+id+"'";
    		PreparedStatement ps=conn.prepareStatement(sqql);
    		int i=ps.executeUpdate();
    		if(i>0) {
    			System.out.println("Booing Cancel");
    		}else {
    			System.out.println("Try Again");
    		}
    	}catch(Exception e) {
    		System.out.println(e);
    	}
    }
}
