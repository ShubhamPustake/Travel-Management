import java.sql.*;
import java.util.*;

class Admin_Menu {
      Scanner sc = new Scanner(System.in);
      Random rnd = new Random();
      Admin_login al = new Admin_login();
      Package pd = new Package();

      public void Menu() {
            while (true) {
                  System.out.println("_________________________________________________________");
                  System.out.println("1.Manage Package");
                  System.out.println("2.Check Package");
                  System.out.println("3.Customer Details");
                  System.out.println("0.Logout");
                  System.out.println("_________________________________________________________");
                  System.out.print("Enter Your Choise--->");
                  int ch1 = sc.nextInt();

                  switch (ch1) {
                        case 1:
                              manage_product();
                              break;
                        case 2:
                              pd.Display();
                              break;
                        case 3:
                        	Customers();
                        	break;
                        case 4:
                              System.out.print("Enter a Product ID--->");
                              int id = sc.nextInt();
                              pd.setId(id);
                              break;
                        case 0:
                              System.out.println("Logging Out");
                              return;
                        default:
                              System.out.println("Invalid Input...!");
                              break;
                  }
            }

      }

      private void manage_product() {
            try {
                  while (true) {
                        System.out.println("__________________________________________");
                        System.out.println("1.Add Package");
                        System.out.println("2.UpdatePackage");
                        System.out.println("3.Delete Package");
                        System.out.println("4.View All Package");
                        System.out.println("0.Back to Main Menu");
                        System.out.println("___________________________________________");
                        System.out.print("Enter Your Choise--->");
                        int ch2 = sc.nextInt();

                        Package product = new Package();
                        switch (ch2) {
                              case 1:
                                   int val=rnd.nextInt(111111,999999);
                                    System.out.println("Product ID---->" + val);

                                    System.out.print("Enter a Package Name--->");
                                    sc.nextLine();
                                    String name = sc.nextLine();

                                    System.out.print("Enter a Product Price--->");
                                    double price = sc.nextDouble();

                                    System.out.print("Enter a Start Date--->");
                                    sc.nextLine();
                                    String date = sc.nextLine();
                                    
                                    System.out.print("Enter a End Date--->");
                                    String edate= sc.nextLine();
                                    
                                    System.out.print("Enter a Details--->");
                                    sc.nextLine();
                                    String details = sc.nextLine();

                                    product.setId(val);
                                    product.setPackage_Name(name);
                                    product.setProduct_Rate(price);
                                    product.setBoarding(date);
                                    product.setDistination(edate);
                                    product.setDetails(details);
                                    product.Add_package();
                                    break;
                              case 2:
                            	  product.Update_Price();
                            	  break;
                                    
                              case 3:
                                    System.out.print("Enter Package ID--->");
                                    int d_id = sc.nextInt();
                                    product.setId(d_id);
                                    product.Delete();
                                    break;
                              case 4:
                                    product.Display();
                                    break;
                              case 0:
                                    return;
                              default:
                                    System.out.println("Invalid Input...!");
                                    break;
                        }
                  }
            } catch (InputMismatchException im) {
                  System.out.println();
            }
      }

      private void Customers() {
            try {
                  Class.forName(DB.classname);
                  Connection conn = DriverManager.getConnection(DB.URL, DB.USERNAME, DB.PASSWORD);
                  String sql = "SELECT * FROM user_details";
                  PreparedStatement ps = conn.prepareStatement(sql);
                  ResultSet rs = ps.executeQuery();
                  while (rs.next()) {
                        int i = rs.getRow();
                        if (i > 0) {
                              System.out.println(i);
                              int ID = rs.getInt(1);
                              String name = rs.getString(2);
                              long mob = rs.getLong(3);
                              String address = rs.getString(4);
                              String username = rs.getString(5);
                              String email=rs.getString(6);
                              System.out.println("Customer ID--->" + ID);
                              System.out.println("Customer Name--->" + name);
                              System.out.println("Mobile No--->" + mob);
                              System.out.println("Address--->" + address);
                              System.out.println("Email--->" + email);
                              System.out.println("Customer Username--->" + username);
                        } else {
                              System.out.println("Data Not Found");
                        }
                  }
            } catch (Exception e) {
                  System.out.println(e);
            }
      }

}