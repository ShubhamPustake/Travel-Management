class DB 
{
      public static final String URL = "jdbc:mysql://localhost:3307/Travel_mgnt";
      public static final String USERNAME = "root";
      public static final String PASSWORD = "root";
      public static final String classname="com.mysql.cj.jdbc.Driver";            
}
